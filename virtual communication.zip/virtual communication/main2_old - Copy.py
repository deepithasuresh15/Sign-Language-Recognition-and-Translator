import cv2
import mediapipe as mp
import numpy as np
import pickle
import google.generativeai as genai
from PIL import Image, ImageTk
import tkinter as tk

# Import nltk before other packages to avoid the metadata issue
import nltk
from nltk.corpus import stopwords
from nltk import pos_tag
from nltk.tokenize import word_tokenize

# Download NLTK resources first
try:
    nltk.download('punkt', quiet=True)
    nltk.download('stopwords', quiet=True)
    nltk.download('averaged_perceptron_tagger', quiet=True)
except:
    pass

# Now import other packages
from gtts import gTTS
import os
from mutagen.mp3 import MP3
from googletrans import Translator
import pygame
import time
from warnings import filterwarnings
filterwarnings('ignore')

# Initialize translator
translator = Translator()

import matplotlib
matplotlib.use('Agg')  # Use non-GUI backend
# Global variables
capturing = False
captured_signs = []
complete_sentence = ""  # Initialize complete_sentence variable
recognized_letter = ""
recognized_word = ""

# Load ASL model
with open('model.pkl', 'rb') as f:
    svm = pickle.load(f)

# Configure and initialize the Generative AI model
genai.configure(api_key='AIzaSyD7JLMPRNpM3ygSSWwkckNM3QPX4WLQMFo')
model = genai.GenerativeModel('gemini-2.5-flash')
chat = model.start_chat(history=[])


# Function to capture and append sign
def capture_sign():
    global capturing
    capturing = True
    capture_button.config(bg="#1565c0", fg="white")
    root.after(300, lambda: capture_button.config(bg="#1e88e5", fg="white"))

def stop_capture(nn, lan):
    global capturing, captured_signs, complete_sentence
    capturing = False

    if captured_signs:
        # Build the recognized word
        complete_word = ''.join(captured_signs)
        print("Recognized Words:", complete_word)

        # Token cleanup
        tokens = word_tokenize(complete_word.lower())
        stop_words = set(stopwords.words('english'))
        filtered_tokens = [w for w in tokens if w.isalnum() and w not in stop_words]
        pos_tags = pos_tag(filtered_tokens)

        # Ask Gemini for grammatically correct sentence
        response = chat.send_message(
            "'" + str(complete_word) + "', {CONSTRUCT A GRAMATICALLY CORRECT SENTENCE USING THE PROVIDED WORDS, WITHOUT ADDING ADDITIONAL NOUNS OR ADJECTIVES}"
        )
        complete_sentence = response.text.strip()
        print("Complete Sentence:", complete_sentence)

        ans = complete_sentence

        # ------------------------------------------------------------
        # 🔥 PLAY ONLY THE USER-SELECTED LANGUAGE
        # ------------------------------------------------------------
        # lan contains: 'ta' / 'kn' / 'hi' / 'en'
        if lan != 'en':  
            # Translate when NOT English
            translated_text = translator.translate(ans, dest=lan).text
            print(f"Translated ({lan}): {translated_text}")
            trans_label.config(text=translated_text)
            text_to_speak = translated_text
            speak_lang = lan
        else:
            # English selected → no translation
            trans_label.config(text="")
            text_to_speak = ans
            speak_lang = 'en'

        # ------------------------------------------------------------
        # 🔊 TTS + Audio playback (ONLY selected language)
        # ------------------------------------------------------------
        try:
            speech = gTTS(text=text_to_speak, lang=speak_lang, slow=False)
            speech.save("output_selected.mp3")

            pygame.mixer.init()
            pygame.mixer.music.load("output_selected.mp3")
            pygame.mixer.music.play()

            audio = MP3("output_selected.mp3")
            time.sleep(audio.info.length)
            pygame.mixer.quit()

        except Exception as e:
            print("TTS error:", e)

        # ------------------------------------------------------------
        # 📄 Save English sentence for logging
        # ------------------------------------------------------------
        try:
            with open("data.txt", "a", encoding="utf-8") as f:
                f.write(ans + "\n")
        except:
            pass

        # Reset for next sentence
        captured_signs = []


# Function to add space after the word
def add_space():
    global captured_signs
    if captured_signs and captured_signs[-1] != ' ':
        captured_signs.append(' ')
        print("Space added.")
        word_label.config(text=f"Recognized Word: {''.join(captured_signs)}")
        space_button.config(bg="#1565c0", fg="white")
        root.after(300, lambda: space_button.config(bg="#1e88e5", fg="white"))

# Function to remove the last captured sign
def remove_last_sign():
    global captured_signs
    if captured_signs:
        captured_signs.pop()  # Remove the last element from the list
        print("Last sign removed.")
        word_label.config(text=f"Recognized Word: {''.join(captured_signs)}")
        backspace_button.config(bg="#1565c0", fg="white")
        root.after(300, lambda: backspace_button.config(bg="#1e88e5", fg="white"))

# Tkinter GUI setup with black background and blue buttons
root = tk.Tk()
root.geometry("1550x800")
root.config(bg="#121212")  # Black background
root.resizable(0,0)
root.title("ASL and Gemini")

# Configure colors
bg_color = "#121212"  # Dark background
button_color = "#1e88e5"  # Blue color for buttons
button_hover = "#1565c0"  # Darker blue for hover
text_color = "#ffffff"  # White text

# Main container
main_frame = tk.Frame(root, bg=bg_color)
main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

# Header
header_frame = tk.Frame(main_frame, bg=bg_color)
header_frame.pack(fill=tk.X, pady=(0, 20))

title_label = tk.Label(header_frame, text="Sign Language Recognition System", 
                      font=("Arial", 24, "bold"), bg=bg_color, fg=button_color)
title_label.pack()

subtitle_label = tk.Label(header_frame, text="Real-time ASL to Text Conversion", 
                         font=("Arial", 14), bg=bg_color, fg=text_color)
subtitle_label.pack(pady=(5, 0))

# Content area
content_frame = tk.Frame(main_frame, bg=bg_color)
content_frame.pack(fill=tk.BOTH, expand=True)

# Left side - Video and recognition display
left_frame = tk.Frame(content_frame, bg=bg_color)
left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

# Video frame
video_frame = tk.Frame(left_frame, bg=bg_color)
video_frame.pack(fill=tk.BOTH, expand=True)

# Canvas for displaying video feed
canvas = tk.Canvas(video_frame, width=640, height=480, bg=bg_color, highlightthickness=0)
canvas.pack(pady=20)

# Recognition display frame (below video)
recognition_frame = tk.Frame(left_frame, bg=bg_color)
recognition_frame.pack(fill=tk.X, pady=20)

# Recognition labels with better styling
class_label = tk.Label(recognition_frame, text="Current Sign: None", 
                      font=("Arial", 14, "bold"), bg=bg_color, fg=button_color)
class_label.pack(pady=5)

letter_label = tk.Label(recognition_frame, text="Recognized Letter: None", 
                       font=("Arial", 14, "bold"), bg=bg_color, fg=button_color)
letter_label.pack(pady=5)

word_label = tk.Label(recognition_frame, text="Recognized Word: ", 
                     font=("Arial", 16, "bold"), bg=bg_color, fg="#4fc3f7")
word_label.pack(pady=10)

sentence_label = tk.Label(recognition_frame, text="Complete Sentence: ", 
                         font=("Arial", 12), bg=bg_color, fg=text_color, wraplength=600)
sentence_label.pack(pady=5)

trans_label = tk.Label(recognition_frame, text="Translation: ", 
                      font=("Arial", 12), bg=bg_color, fg="#4caf50", wraplength=600)
trans_label.pack(pady=5)

# Right side - Control buttons
right_frame = tk.Frame(content_frame, bg=bg_color)
right_frame.pack(side=tk.RIGHT, fill=tk.Y, padx=(20, 0))

# Control buttons section
controls_title = tk.Label(right_frame, text="Controls", 
                         font=("Arial", 16, "bold"), bg=bg_color, fg=button_color)
controls_title.pack(pady=(0, 15))

# Button to capture sign
capture_button = tk.Button(right_frame, text="📸 Capture Sign", command=capture_sign, 
                          font=("Arial", 12, "bold"), bg=button_color, fg="white",
                          relief=tk.RAISED, bd=2, width=20, height=2)
capture_button.pack(pady=10)

# Button to remove the last recognized letter
backspace_button = tk.Button(right_frame, text="⌫ Backspace", command=remove_last_sign,
                            font=("Arial", 12, "bold"), bg=button_color, fg="white",
                            relief=tk.RAISED, bd=2, width=20, height=2)
backspace_button.pack(pady=10)

# Button to add space
space_button = tk.Button(right_frame, text="␣ Add Space", command=add_space,
                        font=("Arial", 12, "bold"), bg=button_color, fg="white",
                        relief=tk.RAISED, bd=2, width=20, height=2)
space_button.pack(pady=10)

# Translation buttons section
translation_title = tk.Label(right_frame, text="Translation", 
                            font=("Arial", 16, "bold"), bg=bg_color, fg=button_color)
translation_title.pack(pady=(30, 15))

# Translation buttons
tamil_button = tk.Button(right_frame, text="🇮🇳 Translate Tamil", 
                        command=lambda: stop_capture(1,'ta'), 
                        font=("Arial", 12, "bold"), bg=button_color, fg="white",
                        relief=tk.RAISED, bd=2, width=20, height=2)
tamil_button.pack(pady=8)

kannada_button = tk.Button(right_frame, text="🇮🇳 Translate Kannada", 
                          command=lambda: stop_capture(2,'kn'), 
                          font=("Arial", 12, "bold"), bg=button_color, fg="white",
                          relief=tk.RAISED, bd=2, width=20, height=2)
kannada_button.pack(pady=8)

hindi_button = tk.Button(right_frame, text="🇮🇳 Translate Hindi", 
                        command=lambda: stop_capture(3,'hi'), 
                        font=("Arial", 12, "bold"), bg=button_color, fg="white",
                        relief=tk.RAISED, bd=2, width=20, height=2)
hindi_button.pack(pady=8)

english_button = tk.Button(right_frame, text="🇺🇸 English Sentence", 
                          command=lambda: stop_capture(4,'en'), 
                          font=("Arial", 12, "bold"), bg=button_color, fg="white",
                          relief=tk.RAISED, bd=2, width=20, height=2)
english_button.pack(pady=8)

# Status bar at bottom
status_frame = tk.Frame(main_frame, bg=bg_color)
status_frame.pack(fill=tk.X, side=tk.BOTTOM, pady=10)
status_label = tk.Label(status_frame, text="Ready to capture signs", 
                       font=("Arial", 10), bg=bg_color, fg=text_color)
status_label.pack()

# MediaPipe setup
mp_drawing = mp.solutions.drawing_utils
mp_hands = mp.solutions.hands

def main():
    global capturing, captured_signs, complete_sentence
    with mp_hands.Hands(min_detection_confidence=0.5, min_tracking_confidence=0.5) as hands:
        cap = cv2.VideoCapture(0)
        # try:
        while cap.isOpened():
            success, image = cap.read()

            if not success:
                print("Ignoring empty camera frame.")
                continue

            image = cv2.resize(image, (640, 480))
            image.flags.writeable = False
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            results = hands.process(image)

            image.flags.writeable = True
            image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

            if results.multi_hand_landmarks:
                for hand_landmarks in results.multi_hand_landmarks:
                    mp_drawing.draw_landmarks(
                        image,
                        hand_landmarks,
                        mp_hands.HAND_CONNECTIONS,
                        mp_drawing.DrawingSpec(color=(30, 136, 229), thickness=2, circle_radius=4),
                        mp_drawing.DrawingSpec(color=(255, 255, 255), thickness=2, circle_radius=2)
                    )

                without_garbage = []
                clean = []
                data = results.multi_hand_landmarks[0]

                data = str(data).strip().split('\n')
                garbage = ['landmark {', '  visibility: 0.0', '  presence: 0.0', '}']

                for i in data:
                    if i not in garbage:
                        without_garbage.append(i)

                for i in without_garbage:
                    i = i.strip()
                    clean.append(i[2:])

                for i in range(0, len(clean)):
                    clean[i] = float(clean[i])

                Class = svm.predict(np.array(clean).reshape(-1, 63))
                Class = Class[0]
                cv2.putText(image, str(Class), (50, 100), cv2.FONT_HERSHEY_SIMPLEX, 2, (30, 136, 229), 3)
                if capturing:
                    # Append recognized sign to the list
                    captured_signs.append(str(Class))

                    # Display the recognized class on the label
                    class_label.config(text=f"Current Sign: {Class}")
                    print(Class)

                    # Reset capturing to False after appending the sign
                    capturing = False

                # Update the letter label with the recognized letter
                letter_label.config(text=f"Recognized Letter: {Class}")
                recognized_letter = Class

                if recognized_letter=='Q':
                    add_space()

                # Update the word label with the recognized word
                word_label.config(text=f"Recognized Word: {''.join(captured_signs)}")
                recognized_word = ''.join(captured_signs)

            else:
                # No hand detected
                class_label.config(text="Current Sign: None")
                letter_label.config(text="Recognized Letter: None")

            # Display the video feed and GUI
            img = Image.fromarray(image)
            img = ImageTk.PhotoImage(img)
            canvas.create_image(0, 0, anchor=tk.NW, image=img)
            canvas.image = img  # Keep reference
            
            # Update the sentence label with the complete sentence
            sentence_label.config(text=f"Complete Sentence: {complete_sentence}")
            root.update()

            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
        # except Exception as e:
        #     print(f"Error: {e}")
        # finally:
        cap.release()
        cv2.destroyAllWindows()

try:
    main()
    root.mainloop()
except Exception as e:
    print(f"Application error: {e}")