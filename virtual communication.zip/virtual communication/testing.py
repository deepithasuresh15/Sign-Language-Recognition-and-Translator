"""
ASL Sign Recognition GUI (refactored)
- Uses MediaPipe for hand landmarks and a pre-trained SVM in model.pkl
- Runs camera loop on a background thread and keeps Tkinter mainloop on the main thread
- Initializes pygame.mixer once and uses it for playback
- Uses google generative AI if API key is provided in env var GOOGLE_GENAI_KEY; otherwise falls back to a simple sentence generator
- Avoids repeated NLTK downloads if resources already present
- Safer handling of translator audio and exceptions

NOTE: Install dependencies in a clean virtual environment before running.
pip install opencv-python mediapipe numpy pillow nltk pygame mutagen googletrans==4.0.0-rc1 gTTS
Optional for Google GenAI: pip install google-generativeai

Place your trained model at 'model.pkl' in the same folder.
Do NOT hardcode API keys in source. Set environment variables instead.
"""

import os
import sys
import traceback
import threading
import time
from warnings import filterwarnings
filterwarnings('ignore')

# --- Standard / third-party imports ---
try:
    import cv2
    import mediapipe as mp
    import numpy as np
    from PIL import Image, ImageTk
    import tkinter as tk
    import pickle
    import pygame
    from mutagen.mp3 import MP3
    from gtts import gTTS
    # googletrans may be flaky; we handle exceptions
    from googletrans import Translator
except Exception as e:
    print("Missing dependency or import error:", e)
    traceback.print_exc()
    raise

# NLTK imports and lazy download (only if needed)
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk import pos_tag

# Try to ensure necessary NLTK data is present. If it's missing, download quietly.
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt', quiet=True)

try:
    nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('stopwords', quiet=True)

try:
    nltk.data.find('taggers/averaged_perceptron_tagger')
except LookupError:
    nltk.download('averaged_perceptron_tagger', quiet=True)

# Optional: Google Generative AI (Gemini). Use only if API key provided.
genai_available = False
chat = None
try:
    google_api_key = os.getenv('GOOGLE_GENAI_KEY')
    if google_api_key:
        import google.generativeai as genai
        genai.configure(api_key=google_api_key)
        model = genai.GenerativeModel('gemini-2.0-flash')
        chat = model.start_chat(history=[])
        genai_available = True
    else:
        print('GOOGLE_GENAI_KEY not set — falling back to local sentence builder')
except Exception as e:
    print('Generative AI initialization failed — falling back to local sentence builder')
    traceback.print_exc()
    genai_available = False

# Initialize translator and handle potential failures
try:
    translator = Translator()
except Exception as e:
    print('googletrans Translator init failed:', e)
    translator = None

# Load SVM model (model.pkl)
svm = None
try:
    with open('model.pkl', 'rb') as f:
        svm = pickle.load(f)
    print('Loaded model.pkl successfully')
except FileNotFoundError:
    print("model.pkl not found. Make sure the file exists in the current directory.")
except Exception as e:
    print('Failed to load model.pkl:', e)
    traceback.print_exc()

# Global state
capturing = False
captured_signs = []
complete_sentence = ""

# Tkinter GUI setup
root = tk.Tk()
root.geometry('1550x800')
root.title('ASL and Gemini (Refactored)')
root.config(bg='#121212')
root.resizable(False, False)

bg_color = '#121212'
button_color = '#1e88e5'
text_color = '#ffffff'

# Header
main_frame = tk.Frame(root, bg=bg_color)
main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

header_frame = tk.Frame(main_frame, bg=bg_color)
header_frame.pack(fill=tk.X, pady=(0, 20))

title_label = tk.Label(header_frame, text='Sign Language Recognition System', font=('Arial', 24, 'bold'), bg=bg_color, fg=button_color)
title_label.pack()

subtitle_label = tk.Label(header_frame, text='Real-time ASL to Text Conversion', font=('Arial', 14), bg=bg_color, fg=text_color)
subtitle_label.pack(pady=(5, 0))

# Content area
content_frame = tk.Frame(main_frame, bg=bg_color)
content_frame.pack(fill=tk.BOTH, expand=True)

left_frame = tk.Frame(content_frame, bg=bg_color)
left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

video_frame = tk.Frame(left_frame, bg=bg_color)
video_frame.pack(fill=tk.BOTH, expand=True)

canvas = tk.Canvas(video_frame, width=640, height=480, bg=bg_color, highlightthickness=0)
canvas.pack(pady=20)

recognition_frame = tk.Frame(left_frame, bg=bg_color)
recognition_frame.pack(fill=tk.X, pady=20)

class_label = tk.Label(recognition_frame, text='Current Sign: None', font=('Arial', 14, 'bold'), bg=bg_color, fg=button_color)
class_label.pack(pady=5)

letter_label = tk.Label(recognition_frame, text='Recognized Letter: None', font=('Arial', 14, 'bold'), bg=bg_color, fg=button_color)
letter_label.pack(pady=5)

word_label = tk.Label(recognition_frame, text='Recognized Word: ', font=('Arial', 16, 'bold'), bg=bg_color, fg='#4fc3f7')
word_label.pack(pady=10)

sentence_label = tk.Label(recognition_frame, text='Complete Sentence: ', font=('Arial', 12), bg=bg_color, fg=text_color, wraplength=600)
sentence_label.pack(pady=5)

trans_label = tk.Label(recognition_frame, text='Translation: ', font=('Arial', 12), bg=bg_color, fg='#4caf50', wraplength=600)
trans_label.pack(pady=5)

# Right side - Controls
right_frame = tk.Frame(content_frame, bg=bg_color)
right_frame.pack(side=tk.RIGHT, fill=tk.Y, padx=(20, 0))

controls_title = tk.Label(right_frame, text='Controls', font=('Arial', 16, 'bold'), bg=bg_color, fg=button_color)
controls_title.pack(pady=(0, 15))

# Buttons will be created later after functions

status_frame = tk.Frame(main_frame, bg=bg_color)
status_frame.pack(fill=tk.X, side=tk.BOTTOM, pady=10)
status_label = tk.Label(status_frame, text='Ready to capture signs', font=('Arial', 10), bg=bg_color, fg=text_color)
status_label.pack()

# MediaPipe setup
mp_drawing = mp.solutions.drawing_utils
mp_hands = mp.solutions.hands

# Initialize pygame mixer once
try:
    pygame.mixer.init()
except Exception as e:
    print('Warning: pygame.mixer.init() failed:', e)

# Utility: play audio file (non-blocking but waits until playback ends)
def play_audio(file_path):
    try:
        if not os.path.exists(file_path):
            print('Audio file not found:', file_path)
            return
        pygame.mixer.music.load(file_path)
        pygame.mixer.music.play()
        # Wait until playback finishes
        while pygame.mixer.music.get_busy():
            pygame.time.wait(100)
    except Exception as e:
        print('Audio playback error:', e)
        traceback.print_exc()

# Application logic functions

def capture_sign():
    global capturing
    capturing = True
    capture_button.config(bg='#1565c0', fg='white')
    root.after(300, lambda: capture_button.config(bg=button_color, fg='white'))


def add_space():
    global captured_signs
    if captured_signs and captured_signs[-1] != ' ':
        captured_signs.append(' ')
        print('Space added.')
        word_label.config(text=f"Recognized Word: {''.join(captured_signs)}")
        space_button.config(bg='#1565c0', fg='white')
        root.after(300, lambda: space_button.config(bg=button_color, fg='white'))


def remove_last_sign():
    global captured_signs
    if captured_signs:
        captured_signs.pop()
        print('Last sign removed.')
        word_label.config(text=f"Recognized Word: {''.join(captured_signs)}")
        backspace_button.config(bg='#1565c0', fg='white')
        root.after(300, lambda: backspace_button.config(bg=button_color, fg='white'))


def simple_sentence_from_words(word_str):
    """Fallback sentence builder if Generative AI is not available."""
    # Basic cleaning and capitalization
    s = word_str.strip()
    if not s:
        return ''
    # If it already looks like a sentence, return it with capitalization
    if s.endswith('.') or s.endswith('!') or s.endswith('?'):
        return s[0].upper() + s[1:]
    return s[0].upper() + s[1:] + '.'


def generate_sentence_with_genai(words):
    try:
        if not genai_available or chat is None:
            return None
        # keep prompt short and safe — instruct the model to re-arrange words into a grammatical sentence
        prompt = f"Construct a grammatically correct sentence using only the provided words without adding new nouns or adjectives: {words}"
        resp = chat.send_message(prompt)
        return getattr(resp, 'text', None)
    except Exception as e:
        print('GenAI call failed:', e)
        traceback.print_exc()
        return None


def safe_translate(text, dest_lang):
    if translator is None:
        return text
    try:
        tr = translator.translate(text, dest=dest_lang)
        return getattr(tr, 'text', text)
    except Exception as e:
        print('Translation failed:', e)
        traceback.print_exc()
        return text


def text_to_speech_and_play(text, lang, out_file):
    try:
        if not text:
            return
        tts = gTTS(text=text, lang=lang, slow=False)
        tts.save(out_file)
        play_audio(out_file)
    except Exception as e:
        print('TTS/playback failed for', lang, e)
        traceback.print_exc()


def stop_capture(nn, lan):
    """Stop capturing, form sentence, translate and speak.
    nn: numeric code for which translation button invoked (1,2,3,4)
    lan: language code for translate-to (e.g. 'ta','kn','hi' or '' for english only)
    """
    global capturing, captured_signs, complete_sentence
    capturing = False
    if not captured_signs:
        print('No captured signs to process')
        return

    complete_word = ''.join(captured_signs)
    print('Recognized Words:', complete_word)

    # Tokenize and filter stopwords (basic)
    try:
        tokens = word_tokenize(complete_word.lower())
        stop_words = set(stopwords.words('english'))
        filtered_tokens = [w for w in tokens if w.isalnum() and w not in stop_words]
        pos_tags = pos_tag(filtered_tokens)
    except Exception:
        filtered_tokens = complete_word.split()
        pos_tags = []

    # Try Generative AI first (if available), else fallback
    sentence = None
    if genai_available:
        sentence = generate_sentence_with_genai(complete_word)

    if not sentence:
        sentence = simple_sentence_from_words(complete_word)

    complete_sentence = sentence or ''
    print('Complete Sentence:', complete_sentence)

    # Speak in English first
    try:
        text_to_speech_and_play(complete_sentence, 'en', 'voice_en.mp3')
    except Exception:
        pass

    translated_text = complete_sentence
    if nn in (1, 2, 3) and lan:
        translated_text = safe_translate(complete_sentence, lan)
        trans_label.config(text=translated_text)
        # speak translation (if lan is a supported gTTS language code)
        try:
            text_to_speech_and_play(translated_text, lan, 'voice_trans.mp3')
        except Exception:
            pass

    # Additionally always provide Tamil and Hindi audio for accessibility
    try:
        tamil_text = safe_translate(complete_sentence, 'ta')
        text_to_speech_and_play(tamil_text, 'ta', 'voice_ta.mp3')
    except Exception:
        pass

    try:
        hindi_text = safe_translate(complete_sentence, 'hi')
        text_to_speech_and_play(hindi_text, 'hi', 'voice_hi.mp3')
    except Exception:
        pass

    # Save to data.txt
    try:
        with open('data.txt', 'a', encoding='utf-8') as f:
            f.write(complete_sentence + '\n')
    except Exception as e:
        print('Failed to write data.txt:', e)

    # Reset captured signs
    captured_signs = []
    word_label.config(text='Recognized Word: ')
    sentence_label.config(text=f'Complete Sentence: {complete_sentence}')

# Create control buttons now (they reference functions above)
capture_button = tk.Button(right_frame, text='📸 Capture Sign', command=capture_sign, font=('Arial', 12, 'bold'), bg=button_color, fg='white', relief=tk.RAISED, bd=2, width=20, height=2)
capture_button.pack(pady=10)

backspace_button = tk.Button(right_frame, text='⌫ Backspace', command=remove_last_sign, font=('Arial', 12, 'bold'), bg=button_color, fg='white', relief=tk.RAISED, bd=2, width=20, height=2)
backspace_button.pack(pady=10)

space_button = tk.Button(right_frame, text='␣ Add Space', command=add_space, font=('Arial', 12, 'bold'), bg=button_color, fg='white', relief=tk.RAISED, bd=2, width=20, height=2)
space_button.pack(pady=10)

translation_title = tk.Label(right_frame, text='Translation', font=('Arial', 16, 'bold'), bg=bg_color, fg=button_color)
translation_title.pack(pady=(30, 15))

# Buttons that call stop_capture with different language codes

tamil_button = tk.Button(right_frame, text='🇮🇳 Translate Tamil', command=lambda: stop_capture(1, 'ta'), font=('Arial', 12, 'bold'), bg=button_color, fg='white', relief=tk.RAISED, bd=2, width=20, height=2)
tamil_button.pack(pady=8)

kannada_button = tk.Button(right_frame, text='🇮🇳 Translate Kannada', command=lambda: stop_capture(2, 'kn'), font=('Arial', 12, 'bold'), bg=button_color, fg='white', relief=tk.RAISED, bd=2, width=20, height=2)
kannada_button.pack(pady=8)

hindi_button = tk.Button(right_frame, text='🇮🇳 Translate Hindi', command=lambda: stop_capture(3, 'hi'), font=('Arial', 12, 'bold'), bg=button_color, fg='white', relief=tk.RAISED, bd=2, width=20, height=2)
hindi_button.pack(pady=8)

english_button = tk.Button(right_frame, text='🇺🇸 English Sentence', command=lambda: stop_capture(4, ''), font=('Arial', 12, 'bold'), bg=button_color, fg='white', relief=tk.RAISED, bd=2, width=20, height=2)
english_button.pack(pady=8)

# Video thread: runs camera loop in background
canvas_image = canvas.create_image(0, 0, anchor=tk.NW)  # placeholder image item


def video_loop():
    global capturing, captured_signs, complete_sentence
    try:
        with mp_hands.Hands(min_detection_confidence=0.5, min_tracking_confidence=0.5) as hands:
            cap = cv2.VideoCapture(0)
            if not cap.isOpened():
                print('Cannot open camera (index 0).')
                return

            while True:
                success, frame = cap.read()
                if not success:
                    time.sleep(0.05)
                    continue

                frame = cv2.resize(frame, (640, 480))
                frame.flags.writeable = False
                frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                results = hands.process(frame_rgb)

                frame.flags.writeable = True
                frame = cv2.cvtColor(frame_rgb, cv2.COLOR_RGB2BGR)

                if results.multi_hand_landmarks:
                    # only use the first hand for prediction
                    hand_landmarks = results.multi_hand_landmarks[0]

                    mp_drawing.draw_landmarks(
                        frame,
                        hand_landmarks,
                        mp_hands.HAND_CONNECTIONS,
                        mp_drawing.DrawingSpec(color=(30, 136, 229), thickness=2, circle_radius=4),
                        mp_drawing.DrawingSpec(color=(255, 255, 255), thickness=2, circle_radius=2)
                    )

                    # convert landmarks text to clean float list (mirrors your prior approach)
                    data = str(hand_landmarks).strip().split('\n')
                    garbage = ['landmark {', '  visibility: 0.0', '  presence: 0.0', '}']
                    without_garbage = [i for i in data if i not in garbage]
                    clean = []
                    for i in without_garbage:
                        i = i.strip()
                        try:
                            clean.append(float(i[2:]))
                        except Exception:
                            pass

                    class_pred = None
                    if svm is not None and len(clean) == 63:
                        try:
                            class_pred = svm.predict(np.array(clean).reshape(-1, 63))[0]
                        except Exception as e:
                            print('Model prediction error:', e)
                            traceback.print_exc()

                    if class_pred is not None:
                        cv2.putText(frame, str(class_pred), (50, 100), cv2.FONT_HERSHEY_SIMPLEX, 2, (30, 136, 229), 3)

                        if capturing:
                            captured_signs.append(str(class_pred))
                            capturing = False
                            class_label.config(text=f'Current Sign: {class_pred}')

                        letter_label.config(text=f'Recognized Letter: {class_pred}')

                        if str(class_pred) == 'Q':
                            # Q used as space marker (as your code did)
                            add_space()

                        word_label.config(text=f"Recognized Word: {''.join(captured_signs)}")

                else:
                    class_label.config(text='Current Sign: None')
                    letter_label.config(text='Recognized Letter: None')

                # update canvas image safely via Tk PhotoImage
                img = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
                img_tk = ImageTk.PhotoImage(img)
                canvas.itemconfig(canvas_image, image=img_tk)
                canvas.image = img_tk

                # update sentence label on the GUI thread
                root.after(0, lambda s=complete_sentence: sentence_label.config(text=f'Complete Sentence: {s}'))

                # small sleep to reduce CPU
                time.sleep(0.01)
    except Exception:
        print('Uncaught exception in video loop:')
        traceback.print_exc()
    finally:
        try:
            cap.release()
        except Exception:
            pass

# Start background video thread and run Tkinter mainloop
video_thread = threading.Thread(target=video_loop, daemon=True)
video_thread.start()

try:
    root.mainloop()
except KeyboardInterrupt:
    print('Interrupted by user')
except Exception:
    print('Application error:')
    traceback.print_exc()
finally:
    try:
        pygame.mixer.quit()
    except Exception:
        pass
    try:
        cv2.destroyAllWindows()
    except Exception:
        pass
